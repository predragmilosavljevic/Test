import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class Domaci2 {
    public static void main(String[] args) {
        
    	new Domaci2();
    }
    
    public Domaci2(){
        
        Scanner ulaz = new Scanner(System.in);
        System.out.println("Unesite svoju dnevnicu: ");
        double dnevnica = ulaz.nextInt();        
        
        JFrame j = new JFrame();
        j.setAlwaysOnTop(true);
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        j.setVisible(true);
        j.setVisible(false);
        JOptionPane.showMessageDialog(j, "Iznos Vaseg mesecnog primanja je: " + plataMesecna(dnevnica));
        System.exit(0);
        
    }
    
    public double plataMesecna(double dnevnica){
        return dnevnica*20;
    }
}